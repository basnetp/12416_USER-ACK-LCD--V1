/**
 * Amigo LCD display board firmware
 * Revision 1
 * 10/02/2019
 * Vivek Vazhoth
 *
 * Copyright (c) 2019 Amigo Mobility International Inc. All Rights Reserved.
 * Description: This is the first prototype code for Amigo display. In this, the display loads
 *              the Amigo logo splashscreen first, then a disclaimer screen followed by the user Interface.
 *              Once on the UI, the app cycles through different UI states giving a demo of regular mode, fault mode etc.
 *
 * 
 *  //Updates:// 
 * Date     
 * change      
 * descr.
 *  //TO DO:
 *  Enable smart-sensor functionality by default. Check for a high on of the buttons.
 *  Pull it high on startup, and 
 * 
 * @private
 */

#include "cs1108.h"
#include "main.h"
#include "gfx/gfx.h"
#include "internal_resource_main.h"
#include "internal_resource_main_color_defines.h"
#include "nvm_w25.h"
#include "system.h"
#include "uart.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

//------------------------------//----------------------------------------------
// Definitions

//#define DEBUG_MODE

#define APP_WaitUntilFinished( x ) while( !x )  //Used to run GFX functions if needed

#define APP_SCREEN_DELAY_MS ( 1000 )
#define I2C_TIMEOUT (2000)

#define INFO_FONT (GFX_RESOURCE_HDR *)&Arial_Bold_14

#define DLUX_BASE_ADDR 0x4E
#define ULTA_BASE_ADDR 0x40
#define HHP_ADDR 0x80

//------------------------------//----------------------------------------------
// Global variables

//------------------------------//----------------------------------------------
// Local variables

static uint8_t _lastHornIn = 0;
static uint8_t _lastButton1In = 0;
static uint8_t _lastButton2In = 0;
static unsigned int _cntrl_runtime = 23;
static uint8_t _fault_code_local = 0;
static uint8_t batt_level = 0;
static uint8_t speed_level = 0;
static uint8_t _chg_NoFloats = 0;
static unsigned int _Low_batt = 0;
static _ulta_wa _lastUltaStatus;
static uint8_t batt_num = 100;
/*
typedef struct {
    uint8_t fault_code;     //Fault code read from controller
    uint8_t batt_level;     //Batt level read from controller
    uint8_t misc_byte;      //Misc bits read from Controller on 0x4C address   
}CS_data;
*/
//Different states of the User Interface screen
typedef enum 
{       create_normal, display_normal, 
        create_fault, display_fault, 
        create_charging, display_charging
}UI_STATE;
//Initialize the enum
UI_STATE ui_state = create_normal;

//Character constants
GFX_XCHAR disclaimer_main_18point[] = {'F','O','R',' ','Y','O','U','R',' ','S','A','F','E','T','Y',':',0xa,0x0a,
                                'T','h','i','s',' ','c','a','r','t',' ','i','s',' ','f','o','r',' ','i','n','d','o','o','r',' ','u','s','e',' ','o','n','l','y', '.', 0x0a,                     
                                'S','t','a','y',' ','a','t',' ','l','e','a','s','t',' ','3',' ','f','e','e','t',' ','a','w','a','y',' ','f','r','o','m',0x0a, 
                                'p','e','o','p','l','e',' ','a','n','d',' ','t','u','r','n',' ','c','a','r','t',' ','o','f','f',' ','w','h','e','n',0x0a,
                                's','t','o','p','p','e','d',' ','i','n',' ','c','h','e','c','k','o','u','t',' ','l','a','n','e','.','B','e','f','o','r','e',0x0a,
                                'b','a','c','k','i','n','g',' ','u','p',',','p','l','e','a','s','e',' ','t','u','r','n',' ','a','r','o','u','n','d',' ','t','o',0x0a,
                                's' ,'e','e',' ','i','f',' ','a','n','y','o','n','e',' ','i','s',' ','b','e','h','i','n','d',' ','y','o','u','.',0x0a,
                                'Y','o','u',' ','a','r','e',' ','r','e','s','p','o','n','s','i','b','l','e',0x0a,'f','o','r',' ','y','o','u','r',' ','d','r','i','v','i','n','g','!',0 
                                };
GFX_XCHAR amigo_address[] = {'A','m','i','g','o',' ','M','o','b','i','l','i','t','y',' ','I','n','t','e','r','n','a','t','i','o','n','a','l',',',' ','I','n','c','.',0x0a,
                                '6','6','9','3',' ','D','i','x','i','e',' ','H','i','g','h','w','a','y',0x0a,
                                'B','r','i','d','g','e','p','o','r','t',',',' ','M','I',' ','4','8','7','2','2', 0
                                };

GFX_XCHAR battlevel_num[] = {'9','0',0};//{'9', '0',0}; 
GFX_XCHAR battlevel_time[] = {'~',' ','6','h',' ', '3', '0', 'm',' ','l','e','f','t',0};
GFX_XCHAR perc_sign[] = {'%',0};
GFX_XCHAR emergency_text[] = {'E','M','E','R','G','E','N','C','Y',0};


GFX_XCHAR status_reverse_mode[] = {'R','E','V','E','R','S','E',' ','O','N','L','Y',' ','M','O','D','E',' ','A','C','T','I','V','E',0};
//GFX_XCHAR batt_life_text[] = {'B','a','t','t','e','r','y',' ','l','i','f','e',0};
GFX_XCHAR batt_life_text[] = {'B',' ',' ','A',' ',' ','T',' ',' ','T',' ',' ','E',' ',' ','R',' ',' ','Y',0};

/*
 Fault code strings
 */
const GFX_XCHAR FAULTCODE[13][25] = 
{
    {'F','A','U','L','T',' ','1','2',':','E','M','B','R','A','K','E',' ','S','H','O','R','T',0},    //11
    {'F','A','U','L','T',' ','1','2',':','E','M','B','R','A','K','E',' ','O','P','E','N',0},        //12
    {'F','A','U','L','T',' ','2','1',':','M','O','T','O','R',' ','S','H','O','R','T',0},            //21
    {'F','A','U','L','T',' ','2','2',':','M','O','T','O','R',' ','O','P','E','N',0},                //22
    {'F','A','U','L','T',' ','2','3',':','P','O','W','E','R',' ','S','H','O','R','T','A','G','E',0},//23
    {'F','A','U','L','T',' ','4','1',':','O','V','E','R',' ','T','E','M','P',0},                    //31
    {'F','A','U','L','T',' ','4','2',':','C','H','A','R','G','E','R',' ','E','R','R','O','R',0},    //41
    {'F','A','U','L','T',' ','4','2',':','C','H','A','R','G','E','R',' ','E','R','R','O','R',0},    //42
    {'F','A','U','L','T',' ','5','1',':','F','E','T',' ','S','H','O','R','T',0},                    //51
    {'F','A','U','L','T',' ','5','2',':','F','E','T',' ','S','H','O','R','T',0},                    //52
    {'F','A','U','L','T',' ','5','3',':','T','H','R','O','T','T','L','E',' ','F','A','I','L',0},    //53
    {'F','A','U','L','T',' ','6','1',':','F','I','R','M','W','A','R','E',0},                        //61
    {'F','A','U','L','T',':','D','I','S','P','L','A','Y',' ','F','W'}
};

//GFX_XCHAR faultcode_throttle[] = {'5','3',':','T','h','r','o','t','t','l','e',' ','F','a','u','l','t',0};
//GFX_XCHAR faultcode_brakeopen[] = {'2','1',':','B','R','A','K','E',' ','O','P','E','N',0};

GFX_XCHAR CHARGING[] = {'C','H','A','R','G','I','N','G',0};
GFX_XCHAR CHARGE_FULL[] = {'F','U','L','L','Y',' ','C','H','A','R','G','E','D',0};
GFX_XCHAR SEAT_LIFT_OPEN[] = {'S','E','A','T',' ','L','I','F','T',' ','O','P','E','N',0};

//GFX_XCHAR SS_DETECT[] = {Obstacle detected};    //Smart-sensor obstacle detected
//GFX_XCHAR ST_WARN_BOUND[] = {Approaching store bounds};  //Smart-track in Warning boundary
//GFX_XCHAR ST_STOP_BOUND[] = {Outside store bounds};


//------------------------------//----------------------------------------------
// Local functions

/*******************************************************************************
 * @brief      Create the second UI screen. 
 *
 * Create the screen, print the disclaimer text.
 *
 * @return     none
 ******************************************************************************/
void create_disclaimer(void)
{
    GFX_ColorSet(DISCLAIMER_BKGCLR);
    GFX_ScreenClear();
    GFX_ColorSet(DISCLAIMER_TXTCLR);
    GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
    GFX_TextStringBoxDraw(5,5,310,230,disclaimer_main_18point, 0, GFX_ALIGN_CENTER);
}

/**'****************************************************************************
 * Function:   fetch_index  
 * ---------------------------------
 * Convert the faultcode into the index for the array where the strings
 *  are stored.
 * 
 * faultcode: Take as input faultcode read from the controller
 * 
 * @return     index
 ******************************************************************************/

 uint8_t fetch_index(int faultcode)
{
    switch(faultcode)
    {
        case 0x11: return 0;    //Embrake short
        case 0x12: return 1;    //Embrake open
        case 0x21: return 2;    //Motor short
        case 0x22: return 3;    //Motor open
        case 0x23: return 4;    //Power shortage
        case 0x31: return 5;    //Over Temp
        case 0x41: return 6;    //Charger is supplying too much voltage
        case 0x42: return 7;    //Charger not dropiing back to Float mode
        case 0x51: return 8;    //Controller Fets shorted
        case 0x52: return 9;    //Regen brake FETs shorted
        case 0x53: return 10;   //Throttle fault
        case 0x61: return 11;   //Bad controller s/w rev
        
        default: return 12;         //Function should never reach here. If it does its
                                    //a bug in the display firmware. 
        
        
    }
}

/**
 * @brief      Check the status of the Horn membrane button 
 *
 * Horn is Active Low. Hence a GPIO read gives 0 when horn button is pushed.
 *
 * @return     true if pushed, false else
 */
bool check_horn(void)
{
    //return 1 if Horn button is being pressed, 0 if not.
    //NOTE: IPIN_HORN_IN is 0 when membrane button is pressed and vice-versa. 
    if(!IPIN_HORN_IN)
        return true;
    else
        return false;   
}

/**
 * @brief      Display debug battery info on Logo splash screen 
 *
 * If the user presses the horn button
 *
 * @return     true if pushed, false else
 */
void display_battery_info(int runtime, int chgNoFloats, int lowbatt)
{
    
    //If the user has pushed down on the horn button while powering up the unit
    //the splashscreen will have info related to battery on the bottom right corner.
    //This is mainly for technicians to warranty battery?
    //Note: Need to replace the arguments for text location with #define ones.
     char s[ 50 ];

    // can fit about 6 lines on screen
    sprintf( s,
             "1: %d\n2: %d\n3: %d",
             runtime, chgNoFloats, lowbatt);
    
    GFX_FontSet(&Arial_Narrow_12);
    GFX_ColorSet(BLACK);
    APP_WaitUntilFinished(GFX_TextStringBoxDraw(280,190,50,15*3,s, 0, GFX_ALIGN_LEFT));
}

/**
 * @brief      Create the footer on UI
 *
 * This will be called inside the UI FSM. Value can be faultcode or charging status
 *
 * @return     None
 */
void update_footer(char DRIVE_STATE, uint8_t fault, _ulta_wa * cs_data)
{
    static uint8_t curr_footer = 0;
    static uint8_t prev_footer = 0;
    
    
    
    
    switch(DRIVE_STATE)
    {
        case create_normal:
        
            
            if(fault != 0)            //If unit if being charged
            {
                curr_footer = 3;
                if(curr_footer != prev_footer)
                {
                    GFX_ColorSet(FOOTER_CLR_RED);//(253,238,57));   //yellow
                    GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
                    GFX_ColorSet(BLACK);
                    GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
                    GFX_TextStringBoxDraw(footer_text_top_x,footer_text_top_y,319,footer_text_height,FAULTCODE[fetch_index(fault)],0, GFX_ALIGN_CENTER);
                }  
            }
             else                                            //Normal operation
            {
                curr_footer = 0;
             if(curr_footer != prev_footer)
             {
                 GFX_ColorSet(DRIVE_BKGCLR);
                 GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
             }
            }
            
            break;
        case display_normal:          //Add this later if needed       
             if(fault != 0)         //rETAIN FAULT CODE MESSAGE
             {}
             else if(cs_data->misc_data.bits.q_stopn)        //Seatlift open
            {
                curr_footer = 1;
                if(curr_footer != prev_footer)
                {
                    GFX_ColorSet(FOOTER_CLR_YELLOW);//(253,238,57));   //yellow
                    GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
                    GFX_ColorSet(BLACK);
                    GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
                    GFX_TextStringBoxDraw(footer_text_top_x,footer_text_top_y,319,footer_text_height,SEAT_LIFT_OPEN,0, GFX_ALIGN_CENTER);
                }
            }
            
            else if(cs_data->misc_data.bits.brk_rel)        //Brake release activated
            {
                curr_footer = 2;
                if(curr_footer != prev_footer)
                {
                    GFX_ColorSet(FOOTER_CLR_YELLOW);//(253,238,57));   //yellow
                    GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
                    GFX_ColorSet(BLACK);
                    GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
                    GFX_TextStringBoxDraw(footer_text_top_x,footer_text_top_y,319,footer_text_height,FAULTCODE[fetch_index(0x12)],0, GFX_ALIGN_CENTER);
                }
            }
            
            else                                            //Normal operation
            {
            curr_footer = 0;
            if(curr_footer != prev_footer)
            {
                GFX_ColorSet(DRIVE_BKGCLR);
                GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
            }
            }
            break;
        
       /* case create_fault:
            if(fault)
            {
                GFX_ColorSet(FOOTER_CLR_RED);//(253,238,57));   //yellow
                GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
                GFX_ColorSet(BLACK);
                GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
                GFX_TextStringBoxDraw(footer_text_top_x,footer_text_top_y,319,footer_text_height,FAULTCODE[fetch_index(fault)],0, GFX_ALIGN_CENTER);
            }
                break;
        
        /*case create_warning:
            GFX_ColorSet(FOOTER_CLR_YELLOW);//(253,238,57));   //yellow
            GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
            GFX_ColorSet(BLACK);
            GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
            GFX_TextStringBoxDraw(footer_text_top_x,footer_text_top_y,319,footer_text_height,status_reverse_mode,0, GFX_ALIGN_CENTER);
            break;
        */
        case create_charging:
        //case display_charging:          //Add this back later if needed
            curr_footer = 4;
            if(prev_footer != curr_footer)
            {    
                GFX_ColorSet(FOOTER_CLR_GREEN);//(253,238,57));   //yellow
                GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
                GFX_ColorSet(BLACK);
                GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
                GFX_TextStringBoxDraw(footer_text_top_x,footer_text_top_y,319,footer_text_height,CHARGING,0, GFX_ALIGN_CENTER);
            }
           
            break;
            
        default:    //Do nothing
            break;
    }
    //Switch case to decide color for the message bar goes here.
    prev_footer = curr_footer;
    }

/**
 * @brief      Create the static symbols on UI
 *
 * This will be called while creating a new screen to display logos/shapes
 *
 * @return     None
 */
void create_static_symbols()
{
    //Draw emergency stop 
    GFX_ImageDraw(235,6, (GFX_RESOURCE_HDR*)MENU_INTERNAL_FLASH_STOPSIGN);
    //and arrow icon 
    //GFX_ImageDraw(295,25, (GFX_RESOURCE_HDR*)MENU_INTERNAL_FLASH_ARROWSIGN);
    //Amigo corporate logo topleft
    GFX_ImageDraw(15,13, (GFX_RESOURCE_HDR*)MENU_INTERNAL_FLASH_AMIGOBW);
    //Battery Icon
    //Draw text for emergency stop
    GFX_ColorSet(BLACK);
    GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_14);
    GFX_TextStringBoxDraw(130,18,strlen(emergency_text)*12,17,emergency_text,0, GFX_ALIGN_CENTER);
     //Battery life description
    GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_14);
    //Sizeof returns bytes. GFX_CHAR seems to use 2 bytes per char. so divide by 2 to find # of char.
    GFX_TextStringBoxDraw(batt_num_pos_x,160,strlen(batt_life_text)*12,20,batt_life_text,0, GFX_ALIGN_LEFT);   
    
    //BATTERY OUTLINE
    GFX_ImageDraw(batt_icon_pos_x, batt_icon_pos_y, (GFX_RESOURCE_HDR*)MENU_INTERNAL_FLASH_BATTICON_FULL);
}


uint8_t calc_battery_perc(volatile uint8_t battery_level)
{
    static uint8_t batt_val = 100;
    //static bool flag_charge = false;
    //uint8_t batt_perc;
    //CS controller sends battery level value like below
    //i2c data         Actual level /no.of bars in old display
    //1                 6
    //2                 5
    //3                 4
    //4                 3
    //5                 2
    //6                 1
    
    switch(battery_level)
    {
        case 0: 
                //flag_charge = true;
                break;          //Return previous value
        
        
        case 1: batt_val = 100; break;
        case 2: batt_val = 83;  break;
        case 3: batt_val = 66;  break;
        case 4: batt_val = 50;  break;
        case 5: batt_val = 33;  break;
        case 6: batt_val = 16;  break;
        default: batt_val = 0;  break;
    }
    
    return batt_val;//Function should not get here
    
}



uint8_t batt_to_bars(uint8_t battery_level)
{
    static uint8_t batt_val = 0;
    
    batt_val = calc_battery_perc(battery_level);
    
    if(batt_val>=5)
        return 2;
    else if(batt_val>=3)
        return 1;
    else
        return 0;
    
}


/**
 * @brief      Draw and update the battery icon on the UI
 *
 * In normal operation draw once. In charging state, use timer module to update charge level.
 *
 * @return     None
 */
void update_batt_icon(UI_STATE state, _ulta_wa * cs_data2)//, uint8_t batt_level)
{
    typedef enum{
        LOW, 
        MEDIUM, 
        FULL}charge;
        
        static charge batt_level = FULL;            //Let's set it as 100 by default
        static charge prev_batt_level = LOW;
        static uint8_t batt_val = 0;
        static TIMER_TICK prevTick = 0;
        static TIMER_TICK updateTick = 0;
        
        
    switch(state)
    {
        case create_normal:
        //case display_normal:
        //case create_fault:
        //case display_fault:
        //case create_charging:
            prevTick = TIMER_Now();
            batt_level = FULL;
            GFX_ImageDraw(batt_icon_pos_x, batt_icon_pos_y, (GFX_RESOURCE_HDR*)MENU_INTERNAL_FLASH_BATTICON_FULL);
            break;
            
        case display_normal:
            batt_val = cs_data2->aux_data;
            batt_level = batt_to_bars(batt_val);     //Convert battery levels to bars {1,2,3}
            //update_batt = true;   
            break;
            
        //case create_fault:
        //case display_fault:
        case create_charging:
            batt_level = LOW;
            prevTick = TIMER_Now();
            break;
            
        case display_charging:
            
            if(TIMER_Since(prevTick)>1000)
            {   
                if(batt_level<=FULL)
                    batt_level++;
                else
                    batt_level = LOW;
                prevTick = TIMER_Now();
            }
            else
                batt_level = batt_level;
            
            break;
    }
    
   // if(batt_level != prev_batt_level )
    //{
   //     prev_batt_level = batt_level;
            switch(batt_level)
            {
                case FULL:
                    //Draw 3 rect
                    GFX_ColorSet(GREEN);
                    APP_WaitUntilFinished(GFX_RectangleFillDraw(62,105,85,117));
                    GFX_ColorSet(ORANGE);
                    APP_WaitUntilFinished(GFX_RectangleFillDraw(62,120,85,132));
                    GFX_ColorSet(RED);
                    APP_WaitUntilFinished(GFX_RectangleFillDraw(62,135,85,147));
                    //while(1);
                    break;
                case MEDIUM:
                    //Draw 2 rect
                    //GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
                    GFX_ColorSet(DRIVE_BKGCLR);
                    APP_WaitUntilFinished(GFX_RectangleFillDraw(62,105,85,117));
                    GFX_ColorSet(ORANGE);
                    APP_WaitUntilFinished(GFX_RectangleFillDraw(62,120,85,132));
                    GFX_ColorSet(RED);
                    APP_WaitUntilFinished(GFX_RectangleFillDraw(62,135,85,147));
                    //break;
                case LOW:
                    //Draw 1 rect
                    //GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
                    GFX_ColorSet(DRIVE_BKGCLR);
                    APP_WaitUntilFinished(GFX_RectangleFillDraw(62,105,85,117));
                    GFX_ColorSet(DRIVE_BKGCLR);
                    APP_WaitUntilFinished(GFX_RectangleFillDraw(62,120,85,132));
                    GFX_ColorSet(RED);
                    APP_WaitUntilFinished(GFX_RectangleFillDraw(62,135,85,147));
                    break;
                    
                default: break; 
            }
      //  }
    }
    
/**
 * @brief      Update the numeric battery level value on UI
 *
 * Use data from i2c to update battery level
 *
 * @return     None
 */
void update_battlevel_num(uint8_t battery_level)
{
    char batt[5];
     //Battery level numeric 
    GFX_ColorSet(BLACK);
    GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Black_75);
    //GFX_TextStringBoxDraw(body_midpoint_x-(batt_num_size_x/2)*((sizeof(battlevel_num))-1),batt_lvl_y,batt_num_size_x*(sizeof(battlevel_num)-1),batt_num_size_y,battlevel_num,0, GFX_ALIGN_CENTER);
    sprintf(batt, "%d",battery_level);
    GFX_TextStringBoxDraw(batt_num_pos_x,batt_num_pos_y,batt_font_size_x*(strlen(batt)),batt_font_size_y, batt, 0, GFX_ALIGN_LEFT);//batt_font_size_x*(sizeof(batt))
    //Print smaller percentage
    GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
    //GFX_TextStringBoxDraw(batt_num_pos_x+batt_font_size_x*4,batt_num_pos_y+50,batt_num_pos_x+batt_font_size_x*4+18, 18*1,batt_font_size_y, "%", 0, GFX_ALIGN_LEFT);
    //GFX_TextStringBoxDraw(perc_pos_x,perc_pos_y,perc_pos_x+perc_font_size_x, perc_pos_y+perc_font_size_y, "%", 0, GFX_ALIGN_LEFT);
    GFX_TextStringBoxDraw(250,130,perc_font_size_x, perc_font_size_y, "%", 0, GFX_ALIGN_LEFT);
}


/**
 * @brief      State machine for UI screen
 *
 * This will be called inside the Main periodically
 *
 * @return     None
 */
void UI_state(uint8_t fc, _ulta_wa * cs_data)//uint8_t batt, uint8_t speed)
{
    //static enum UI_STATE ui_state = create_normal;
    static TIMER_TICK prevTick; 
    
    switch(ui_state)
    {
        
        case create_normal:
            // Draw the main user interface screen. 
            GFX_ColorSet(DRIVE_BKGCLR);
            GFX_ScreenClear();           
            update_battlevel_num(calc_battery_perc(cs_data->aux_data));// CS1108_ultaStatus.aux_data));
            update_footer(ui_state, fc, cs_data);
           // create_dash();
            create_static_symbols();
            ui_state = display_normal;
            //prevTick = TIMER_Now();
            break;
        
        case display_normal:
            update_batt_icon(ui_state, cs_data);
            update_battlevel_num(calc_battery_perc(cs_data->aux_data));
            update_footer(ui_state, fc, cs_data);
            if(cs_data->misc_data.bits.chg_mode)      //if charging bit is ON - Active High
                ui_state = create_charging;
            else
                ui_state = display_normal;
            
            //if(TIMER_Since(prevTick)>3000)
                //ui_state = create_fault;
            break;
        /*    
        case create_fault:
            //GFX_ColorSet(DRIVE_BKGCLR);//remove later?
            //GFX_ScreenClear();//remove later?
            update_footer(create_fault, fc, cs_data);
            GFX_ColorSet(FOOTER_CLR_RED);//(253,238,57));   //yellow
            GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
            GFX_ColorSet(BLACK);
            GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
            GFX_TextStringBoxDraw(footer_text_top_x,footer_text_top_y,319,footer_text_height,fc,0, GFX_ALIGN_CENTER);
            ui_state = display_fault;
            prevTick = TIMER_Now();
            break;
        */
            
        /*
        case display_fault:  
             update_batt_icon(ui_state);
            if(TIMER_Since(prevTick)>3000)
                ui_state = create_charging;
           break;
        */
            
        case create_charging:
            //GFX_ColorSet(DRIVE_BKGCLR);//remove later?
            //GFX_ScreenClear();//remove later?
            /*GFX_ColorSet(FOOTER_CLR_GREEN);//(253,238,57));   //yellow
            GFX_RectangleFillDraw(footer_topleft_x,footer_topleft_y,footer_bottomright_x,footer_bottomright_y);
            GFX_ColorSet(BLACK);
            GFX_FontSet((GFX_RESOURCE_HDR*)&Arial_Bold_18);
            GFX_TextStringBoxDraw(footer_text_top_x,footer_text_top_y,319,footer_text_height,CHARGING,0, GFX_ALIGN_CENTER);
             * */
            update_footer(ui_state, fc, cs_data);
            update_batt_icon(ui_state,  cs_data);
            ui_state = display_charging;
            //prevTick = TIMER_Now();
            break;
            
        case display_charging:
            update_batt_icon(ui_state, cs_data);
            if(!(cs_data->misc_data.bits.chg_mode))      //if charging bit is Off - Go back to normal drive
                //ui_state = create_normal;
             //if(TIMER_Since(prevTick)>3000)
                //ui_state = create_normal;
            break;
            
        default: break;    
            
    }
    
}

void create_splashscreen()
{
    // Splash image
    APP_WaitUntilFinished( GFX_ImageDraw( 0, 0, APP_INTERNAL_FLASH_SPLASH_IMAGE) );
    //print address text
    GFX_ColorSet(BLACK);
    GFX_FontSet(&Arial_Narrow_12);
    APP_WaitUntilFinished(GFX_TextStringBoxDraw(20,180,280,17*3,amigo_address, 0, GFX_ALIGN_CENTER));
    //Display debug info if user had pressed horn at powerup
    
}


//------------------------------//----------------------------------------------
// Public functions

int main( void )
{
    //Local variables
    uint8_t _temp = 0, _prevtemp = 0;
    
    TIMER_TICK _timer = 0;
    
    bool print_flag = true;
    
    //CS_data 1108_data;
     
    // initialize hardware components and peripherals
    SYSTEM_Initialize();

    // Motor controller interface
    CS1108_Initialize(DLUX_BASE_ADDR);
    
    // Init graphics engine
    GFX_Initialize();

    // Serial port
    UART1_Initialize();
    
    
    //DRV_GFX_PaletteDisable();
    GFX_PaletteSet( (GFX_RESOURCE_HDR *)&CrayolaByHue, 0, 255 );
    
    //GFX_ScreenClear();
    SYSTEM_Backlight( 100 );
    
    create_splashscreen();
    
       //Stay here until data is read from controller or timeout reaches
    _timer = TIMER_Now();
    while(!DISPLAY_ACK_DONE)
    {
        if(TIMER_Since(_timer) > I2C_TIMEOUT)
        {
            DISPLAY_ACK_DONE = true;
            break;
        }
              
    } 
    
    __delay_ms( APP_SCREEN_DELAY_MS*2);
    
    //Turn ON HHP mode to read parameters
    CS1108_Initialize(HHP_ADDR);
    
    //Stay here until data is read from controller or timeout reaches
    _timer = TIMER_Now();
    while(!DATA_READ)
    {
        if(TIMER_Since(_timer) > I2C_TIMEOUT)
        {
            DATA_READ = true;
            break; 
        }
             
    }        
    
   // __delay_ms( APP_SCREEN_DELAY_MS * 1 );
    
    _cntrl_runtime = (RX_data.i2c_data[1].rx_data<<8)|(RX_data.i2c_data[2].rx_data);
    _fault_code_local = RX_data.i2c_data[0].rx_data;
    _chg_NoFloats = RX_data.i2c_data[3].rx_data;
    _Low_batt = (RX_data.i2c_data[4].rx_data) + (RX_data.i2c_data[5].rx_data)*60;        //in minutes
    
    //Switch back to Display i2c mode
    CS1108_Initialize(DLUX_BASE_ADDR);
    
    if(check_horn())
    {
      display_battery_info(_cntrl_runtime, _chg_NoFloats, _Low_batt);
      __delay_ms( APP_SCREEN_DELAY_MS * 1 );
    }
    //DATA_READ = false;
    
    
    //Display the second splash screen. The disclaimer menu.
    create_disclaimer();
    
    __delay_ms( APP_SCREEN_DELAY_MS * 2 );
    
    memset( &_lastUltaStatus, 0, sizeof( _ulta_wa ) );

    //Save the approximate time main() is entered 
    _timer = TIMER_Now();

    
    
    
    
    
    while( 1 )
    {
    
        //_temp = RX_data.i2c_data[0].rx_data;
    
//#ifdef DEBUG_MODE         
/*         if( CBUF_Len( I2C_rxQ ) > 2 )
         {
             uint8_t flag = CBUF_Pop( I2C_rxQ );
             uint8_t rx = CBUF_Pop( I2C_rxQ );
             uint8_t tx = CBUF_Pop( I2C_rxQ );
             printf( ": %c%c %02X %02X\n", ( flag & 0x20 ) ? 'D' : 'A', ( flag & 0x04 ) ? 'R' : 'W', rx, tx );
         }
  */      
         //printf( "MODE: %02X\n", _lastUltaStatus.mode_data );   
        // printf( "MISC: %02X\n", _lastUltaStatus.misc_data.byte);
         //printf( "LED: %02X\n", _lastUltaStatus.led_data );
        // printf( "AUX: %02X\n", _lastUltaStatus.aux_data );
        
       /* if(print_flag) 
        {   //__delay_ms( APP_SCREEN_DELAY_MS * 0.5 );
            //printf("Fault: %02X\n", RX_data.i2c_data[0].rx_data);
           //printf("Runtime: %02d\n", (RX_data.i2c_data[1].rx_data<<8)|(RX_data.i2c_data[2].rx_data));
            ///printf("ChargeNoFloat: %02X\n", RX_data.i2c_data[3].rx_data);
           // //printf("LowBatt: %02d\n", ((RX_data.i2c_data[4].rx_data) + ((RX_data.i2c_data[5].rx_data)*60)));
            printf("Batt: %d\n",CS1108_ultaStatus.aux_data );
            //printf("Speed: %d\n",CS1108_ultaStatus.led_data );
           // printf("Mode: %d\n", CS1108_ultaStatus.mode_data);
            printf("%X ", CS1108_ultaStatus.misc_data.byte);
            __delay_ms( APP_SCREEN_DELAY_MS * 0.1 );
            
            //printf("Fault: %02X\n", RX_data.i2c_data[0].rx_data);
            //print_flag = false;
            //FAULT_CODE_READ_EXT = false;
        }
        //RX_data.
#endif        
            //_prevtemp = _temp;
        
        batt_level = CS1108_ultaStatus.aux_data;    //Save latest battery level
        speed_level = CS1108_ultaStatus.led_data;                 //Save latest speed level
        if( CBUF_Len( I2C_rxQ ) > 0 )
        {
            uint8_t flag = CBUF_Pop( I2C_rxQ );
            printf( " FLAG: %d", flag);
        }
     /*
        if( TIMER_Since( _timer ) >= 1000 )
        {
            //OPIN_LED_1 = !OPIN_LED_1;
            OPIN_LED_2 = !OPIN_LED_2;
            OPIN_GPS_ENABLE = !OPIN_GPS_ENABLE;

            _timer = TIMER_Now();
        }
        */
        //_UpdateInfoBox();
        UI_state(_fault_code_local, &CS1108_ultaStatus);//batt_level, speed_level );    
        CS1108_Tasks();
    }
}

/**
 * Hook for C library printf function(s).
 *
 * Prints the message to the serial port
 */
int __attribute__( ( __section__( ".libc.write" ) ) ) write( int handle, void *buffer, unsigned int len )
{

    char *p = (char *)buffer;
    unsigned int i;

    for( i = 0; i < len; i++ )
    {
        UART1_Put( *p++ );
    }

    return ( len );
}
